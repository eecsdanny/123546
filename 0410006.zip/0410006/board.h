#pragma once
#include <array>
#include <iostream>
#include <iomanip>

/**
 * array-based board for 2048
 *
 * index (1-d form):
 *  (0)  (1)  (2)  (3)
 *  (4)  (5)  (6)  (7)
 *  (8)  (9) (10) (11)
 * (12) (13) (14) (15)
 *
 */
class board {
public:
	typedef uint32_t cell;
	typedef std::array<cell, 4> row;
	typedef std::array<row, 4> grid;
	typedef uint64_t data;
	typedef int reward;

public:
	board() : tile(), attr(0) {}
	board(const grid& b, data v = 0) : tile(b), attr(v) {}
	board(const board& b) = default;
	board& operator =(const board& b) = default;

	operator grid&() { return tile; }
	operator const grid&() const { return tile; }
	row& operator [](unsigned i) { return tile[i]; }
	const row& operator [](unsigned i) const { return tile[i]; }
	cell& operator ()(unsigned i) { return tile[i / 4][i % 4]; }
	const cell& operator ()(unsigned i) const { return tile[i / 4][i % 4]; }

	data info() const { return attr; }
	data info(data dat) { data old = attr; attr = dat; return old; }

public:
	bool operator ==(const board& b) const { return tile == b.tile; }
	bool operator < (const board& b) const { return tile <  b.tile; }
	bool operator !=(const board& b) const { return !(*this == b); }
	bool operator > (const board& b) const { return b < *this; }
	bool operator <=(const board& b) const { return !(b < *this); }
	bool operator >=(const board& b) const { return !(*this < b); }

public:
	//count score
	int total(){
		int score_tmp = 0;
		int cell_count[15] ={0};
		//count
		//std::cout <<"=============\n";
		for(int r=0; r<4; ++r)
		{
			for(int c=0; c<4; ++c)
			{
				cell_count[tile[r][c]] +=1;
				//std::cout << tile[r][c];
			}
			//std::cout <<std::endl;
		}
		//std::cout <<std::endl<<"=============\n";
		//add
		for(int i=3; i<15; ++i)
		{
			int index_score = 1;
			//std::cout << i << ": " <<cell_count[i] <<std::endl;
			for(int s=1; s<=i-2; ++s)
			{
				index_score*=3;
			}
			score_tmp += (index_score ==1) ? 0 : cell_count[i]*index_score;
			//std::cout << "index:"<< i << "\ncount" <<cell_count[i] << "\nscore" << index_score << "\n";
		}
		return score_tmp;
	}
	/**
	 * place a tile (index value) to the specific position (1-d form index)
	 * return 0 if the action is valid, or -1 if not
	 */
	reward place(unsigned pos, cell til) {
		if (pos >= 16) return -1;
		if (til != 1 && til != 2 && til !=3) return -1;
		operator()(pos) = til;
		//std::cout<<"ddddd:" << pos << til <<'\n';
		return 0;
	}

	/**
	 * apply an action to the board
	 * return the reward of the action, or -1 if the action is illegal
	 */
	reward slide(unsigned opcode) {
		switch (opcode & 0b11) {
		case 0: return slide_up();
		case 1: return slide_right();
		case 2: return slide_down();
		case 3: return slide_left();
		default: return -1;
		}
	}

	reward slide_left() {
		pre_op = 3;
		// for (int r = 0; r < 4; r++) {
		// 	auto& row = tile[r];
		// 	int top = 0, hold = 0, merge = 0;
		// 	for (int c = 0; c < 4; c++) {
		// 		int tile = row[c];
		// 		if (tile == 0) continue;
		// 		row[c] = 0;
		// 		if (hold) {
		// 			//tile adding
		// 			if (tile == hold ) {
		// 				row[top++] = ++tile;
		// 				//score += (1 << tile);
		// 				hold = 0;
		// 			} else {
		// 				row[top++] = hold;
		// 				hold = tile;
		// 			}
		// 		} else {
		// 			hold = tile;
		// 		}
		// 	}
		// 	if (hold) tile[r][top] = hold;
		// }
		board prev = *this;
		reward score = -1;
		int valid = 0;
		for(int r=0; r<4; ++r)
		{
			auto& row = tile[r];
			bool merge = 0;
			int merge_index=0;
			//find merge
			for(int c=0; c<2; ++c)
			{
				// 1+2 merge
				if( (row[c] * row[c+1] ) == 2)
				{
					tile[r][c] = 3;
					merge_index = c;
					if(score < 3)
						score = 3;
					merge = 1;
					break;
				}
				// else merge
				if( (row[c] == row[c+1]) && row[c] > 2 )
				{
					tile[r][c] = tile[r][c] + 1;
					if(score < tile[r][c] + 1)
						score = tile[r][c] + 1;
					merge_index = c;
					merge = 1;
					break;
				}
			}
			//std::cout << "merge_index" <<merge_index <<'\n';
			if(merge)
			{
				valid = 1;
				for(int c = merge_index+1; c<3; ++c)
				{
					tile[r][c] = tile[r][c+1];
				}
				tile[r][3] = 0;
				continue;
			}
			// no merge check space
			else
			{
				int space_index = -1;
				for(int c=0; c<4; ++c)
				{
					if(row[c] == 0)
					{
						space_index = c;
						valid = 1;
						if(score == -1)
							score = 0;
						break;
					}
				}
				//std::cout << "row: " << r <<'\n';
				//std::cout << "space_index: " <<space_index <<'\n';
				//no space
				if(space_index == -1)
					continue;
				//move left
				for(int c=space_index; c<3; ++c)
				{
					//std::cout << "tile "<<r <<c <<":" <<tile[r][c]<<"=>" <<tile[r][c+1] <<'\n';
					tile[r][c] = tile[r][c+1];
				}
				tile[r][3] = 0;
			}
		}
		if(valid == 0)
			return -1;
		// std::cout <<"===========after slide:=============\n";
		// for(int r=0; r<4; ++r)
		// {
		// 	for(int c=0; c<4; ++c)
		// 	{
		// 		std::cout << tile[r][c];
		// 	}
		// 	std::cout <<std::endl;
		// }
		//std::cout <<"=============================\n";
		// maybe space on cell 4 -> -1
		return (*this != prev) ? score : -1;
	}
	reward slide_right() {
		reflect_horizontal();
		reward score = slide_left();
		reflect_horizontal();
		pre_op = 1;
		return score;
	}
	reward slide_up() {
		rotate_right();
		reward score = slide_right();
		rotate_left();
		pre_op = 0;
		return score;
	}
	reward slide_down() {
		
		rotate_right();
		reward score = slide_left();
		rotate_left();
		pre_op = 2;
		return score;
	}

	void transpose() {
		for (int r = 0; r < 4; r++) {
			for (int c = r + 1; c < 4; c++) {
				std::swap(tile[r][c], tile[c][r]);
			}
		}
	}

	void reflect_horizontal() {
		for (int r = 0; r < 4; r++) {
			std::swap(tile[r][0], tile[r][3]);
			std::swap(tile[r][1], tile[r][2]);
		}
	}

	void reflect_vertical() {
		for (int c = 0; c < 4; c++) {
			std::swap(tile[0][c], tile[3][c]);
			std::swap(tile[1][c], tile[2][c]);
		}
	}

	/**
	 * rotate the board clockwise by given times
	 */
	void rotate(int r = 1) {
		switch (((r % 4) + 4) % 4) {
		default:
		case 0: break;
		case 1: rotate_right(); break;
		case 2: reverse(); break;
		case 3: rotate_left(); break;
		}
	}

	void rotate_right() { transpose(); reflect_horizontal(); } // clockwise
	void rotate_left() { transpose(); reflect_vertical(); } // counterclockwise
	void reverse() { reflect_horizontal(); reflect_vertical(); }

public:
	friend std::ostream& operator <<(std::ostream& out, const board& b) {
		out << "+------------------------+" << std::endl;
		for (auto& row : b.tile) {
			out << "|" << std::dec;
			for (auto t : row) out << std::setw(6) << ((1 << t) & -2u);
			out << "|" << std::endl;
		}
		out << "+------------------------+" << std::endl;
		return out;
	}

private:
	grid tile;
	data attr;
public:
	int pre_op;
};
